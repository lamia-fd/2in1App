package com.example.a2in1app

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.rec.view.*

class recyclerView (val context: Context, private val UserInput: ArrayList<String>): RecyclerView.Adapter<recyclerView.ItemHolder>() {
    // lateinit var tv:TextView

    class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        return ItemHolder(LayoutInflater.from(parent.context).inflate(R.layout.rec, parent, false))
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {
        val userinput=UserInput[position]
        holder.itemView.apply {
            tv.text =userinput


        }
    }

    override fun getItemCount()= UserInput.size

}